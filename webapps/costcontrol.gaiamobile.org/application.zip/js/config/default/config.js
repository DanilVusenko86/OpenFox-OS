/* global ConfigManager */
'use strict';

ConfigManager.setConfig({});
